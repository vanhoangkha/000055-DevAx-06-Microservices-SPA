//
// Stubbed-out implementation
//
var apigClientFactory_TripSearch = {};
apigClientFactory_TripSearch.newClient = function (config) {};

