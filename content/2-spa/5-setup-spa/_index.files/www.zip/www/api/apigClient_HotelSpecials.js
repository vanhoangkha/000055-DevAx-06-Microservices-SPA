//
// Stubbed-out implementation
//
var apigClientFactory_HotelSpecials = {};
apigClientFactory_HotelSpecials.newClient = function (config) {};
