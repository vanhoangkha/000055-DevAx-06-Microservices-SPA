//
// Stubbed-out implementation
//
var apigClientFactory_FlightSpecials = {};
apigClientFactory_FlightSpecials.newClient = function (config) {};

